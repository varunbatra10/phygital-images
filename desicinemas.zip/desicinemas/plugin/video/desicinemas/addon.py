import sys
import requests
from bs4 import BeautifulSoup
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmc
import urllib.parse

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
base_url = 'https://desicinemas.tv'

def build_url(query):
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

def fetch_html(url):
    response = requests.get(url)
    return response.text

def list_videos():
    url = base_url + "/movies"
    html = fetch_html(url)
    soup = BeautifulSoup(html, 'html.parser')

    # Example: Find all movie links
    movies = soup.find_all('div', class_='ml-item')
    for movie in movies:
        title = movie.find('h2').text
        video_url = movie.find('a')['href']
        
        # Add each video to Kodi
        list_item = xbmcgui.ListItem(label=title)
        list_item.setInfo('video', {'title': title})
        video_url = build_url({'action': 'play', 'video': video_url})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=video_url, listitem=list_item, isFolder=False)
    
    xbmcplugin.endOfDirectory(addon_handle)

def play_video(video_url):
    # Fetch the actual video URL from the page (this is an example, the actual implementation may vary)
    html = fetch_html(video_url)
    soup = BeautifulSoup(html, 'html.parser')
    video_src = soup.find('iframe')['src']  # Example: get the video src from an iframe
    
    play_item = xbmcgui.ListItem(path=video_src)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    if params:
        if params['action'] == 'list':
            list_videos()
        elif params['action'] == 'play':
            play_video(params['video'])
    else:
        list_videos()

if __name__ == '__main__':
    router(sys.argv[2][1:])
